#ifndef SMAT_H
#define SMAT_H

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

//#include "FP_command.h"
//#include "FPS_GT511C3.h"
#include <SoftwareSerial.h>

#define __Cascade_All__ 8   //cascade level
void LED_Decode(unsigned char DataPin,unsigned char LED_R,unsigned char LED_G,unsigned char LED_B);
void fingeprintEnroll(SoftwareSerial &FP_Serial);
int FP_GO(SoftwareSerial &FP_Serial);
//int FPS_ID(FPS_GT511C3 &fps);
#endif
