#include "smat.h"
#include "FP_command.h"
//#include "FPS_GT511C3.h"
//#include <SoftwareSerial.h>

void LED_Decode(unsigned char DataPin,unsigned char LED_R,unsigned char LED_G,unsigned char LED_B)	//LED_Decode1
{										//LED_Decode2
	unsigned char i = 0;				//LED_Decode3
	unsigned char Data_temp = 0;		//LED_Decode4
	noInterrupts();  					//LED_Decode5
	for(i = 0;i<__Cascade_All__;i++)	//LED_Decode6
	{									//LED_Decode7
		Data_temp = LED_B & 0x80;		//LED_Decode8
		digitalWrite(DataPin,HIGH);		//LED_Decode9
		if(Data_temp != 0x80)			//LED_Decode10
			digitalWrite(DataPin,LOW);	//LED_Decode11
		else 							//LED_Decode12
			digitalWrite(DataPin,HIGH);	//LED_Decode13
		LED_B = LED_B <<1;				//LED_Decode14
		digitalWrite(DataPin,LOW); 		//LED_Decode15
	}  									//LED_Decode16
	for(i = 0;i<__Cascade_All__;i++)	//LED_Decode17
	{									//LED_Decode18
		Data_temp = LED_R & 0x80;		//LED_Decode19
		digitalWrite(DataPin,HIGH);		//LED_Decode20
		if(Data_temp != 0x80)			//LED_Decode21
			digitalWrite(DataPin,LOW);	//LED_Decode22
		else 							//LED_Decode23
			digitalWrite(DataPin,HIGH);	//LED_Decode24
		LED_R = LED_R <<1;				//LED_Decode25
		digitalWrite(DataPin,LOW); 		//LED_Decode26
	}  									//LED_Decode27
	for(i = 0;i<__Cascade_All__;i++)	//LED_Decode28
	{									//LED_Decode29
		Data_temp = LED_G & 0x80;		//LED_Decode30
		digitalWrite(DataPin,HIGH);		//LED_Decode31
		if(Data_temp != 0x80)			//LED_Decode32
			digitalWrite(DataPin,LOW);	//LED_Decode33
		else 							//LED_Decode34
			digitalWrite(DataPin,HIGH);	//LED_Decode35
		LED_G = LED_G <<1;				//LED_Decode36
		digitalWrite(DataPin,LOW); 		//LED_Decode37
	}  									//LED_Decode38
	interrupts();    					//LED_Decode39
}										//LED_Decode40
		

void fingeprintEnroll(SoftwareSerial &FP_Serial)	//Enroll_smat
{  													//Enroll_smat01
	unsigned char choose_function;   				//for menu handle
	int enrollid=0;  								//Enroll_smat01-1
	FP_LED_open(FP_Serial);							//Enroll_smat01-2
	delay(3000);									//Enroll_smat01-3
	int loop_time = 1;  							//Enroll_smat02-1
	while (1)										//Enroll_smat02-2
	{  												//Enroll_smat02-3
		delay(100);  								//Enroll_smat02-4
		FP_CAPTUREFINGER(0, FP_Serial);  			//Enroll_smat02-5
		if (FP_boolReturnACK())  					//Enroll_smat02-6
		{  											//Enroll_smat02-7
			FP_CAPTUREFINGER(0, FP_Serial);  		//Enroll_smat02-8
			if (FP_boolReturnACK())  				//Enroll_smat02-9
			break;  								//Enroll_smat02-10
		}  											//Enroll_smat02-11
		if (loop_time > 30)  						//Enroll_smat02-12
		{  											//Enroll_smat02-13
			FP_LED_close(FP_Serial);  				//Enroll_smat02-14
			return;  								//Enroll_smat02-15
		}  											//Enroll_smat02-16
		loop_time++;  								//Enroll_smat02-17
	}  												//Enroll_smat02-18
	FP_DeleteAll(FP_Serial);						//Enroll_smat03
	FP_EnrollStart(enrollid, FP_Serial);  			//Enroll_smat04
	FP_CAPTUREFINGER(0, FP_Serial);					//Enroll_smat05
	bool bret=FP_boolReturnACK();					//Enroll_smat06
	digitalWrite(9,0);  							//Enroll_smat07
	int iret=0;  									//Enroll_smat08
	if(bret!=false)  								//Enroll_smat09-1
	{  												//Enroll_smat09-2
		FP_Enroll(1, FP_Serial);  					//Enroll_smat09-3
	}												//Enroll_smat09-4
	for(int i=10;i>0;i--)							//Enroll_smat10-1
	{												//Enroll_smat10-2
		FP_LED_close(FP_Serial);					//Enroll_smat10-3
		FP_LED_open(FP_Serial);						//Enroll_smat10-4
	}												//Enroll_smat10-5
	delay(1000);									//Enroll_smat11
	FP_CAPTUREFINGER(0, FP_Serial);					//Enroll_smat12-1
	bret=FP_boolReturnACK();						//Enroll_smat12-2
	digitalWrite(11,0);  							//Enroll_smat12-3
	if(bret!=false)  								//Enroll_smat13-1
	{  												//Enroll_smat13-2
		FP_Enroll(2, FP_Serial);  					//Enroll_smat13-3
	}												//Enroll_smat13-4
	for(int i=10;i>0;i--)							//Enroll_smat14-1
	{												//Enroll_smat14-2
		FP_LED_close(FP_Serial);					//Enroll_smat14-3
		FP_LED_open(FP_Serial);						//Enroll_smat14-4
	}												//Enroll_smat14-5
	delay(1000);									//Enroll_smat15
	FP_CAPTUREFINGER(0, FP_Serial);					//Enroll_smat16-1
	bret=FP_boolReturnACK();						//Enroll_smat16-2
	if(bret!=false)  								//Enroll_smat17
	{  												//Enroll_smat18
		FP_Enroll(3, FP_Serial);  					//Enroll_smat19
		bret=FP_getReturnACK();						//Enroll_smat20
		if(bret!=false)  							//Enroll_smat21
		{  											//Enroll_smat22
			digitalWrite(10,0);  					//Enroll_smat23
		}  											//Enroll_smat24
		else  										//Enroll_smat25
		{  											//Enroll_smat26
			digitalWrite(10,1);  					//Enroll_smat27
		}  											//Enroll_smat28
	}  												//Enroll_smat29
FP_LED_close(FP_Serial);  							//Enroll_smat30
}  													//Enroll_smat31



int FP_GO(SoftwareSerial &FP_Serial)
{										//FP_GOsmat
	unsigned char choose_function;   	//for menu handle
	FP_LED_open(FP_Serial);				//FP_GOsmat01-1
	if (!FP_boolReturnACK()){			//FP_GOsmat01-2
		FP_LED_close(FP_Serial);		//FP_GOsmat01-3
		return(0);						//FP_GOsmat01-4
	}									//FP_GOsmat01-5
	FP_CAPTUREFINGER(0, FP_Serial); 	//FP_GOsmat02-1
	if (!FP_boolReturnACK()){ 			//FP_GOsmat02-2
	FP_LED_close(FP_Serial);			//FP_GOsmat02-3
	return(0);							//FP_GOsmat02-4
	}									//FP_GOsmat02-5
	FP_Identify(FP_Serial);				//FP_GOsmat03-1
	if (FP_boolReturnACK()){			//FP_GOsmat03-2
		for(int i=3;i>0;i--)			//FP_GOsmat03-3
		{								//FP_GOsmat03-4
			FP_LED_open(FP_Serial);		//FP_GOsmat03-5
			FP_LED_close(FP_Serial);	//FP_GOsmat03-6
		}								//FP_GOsmat03-7
		return(1);						//FP_GOsmat03-8
	}									//FP_GOsmat03-9
	else {								//FP_GOsmat04-1
		for(int i=3;i>0;i--)			//FP_GOsmat04-2
		{								//FP_GOsmat04-3
			FP_LED_open(FP_Serial);		//FP_GOsmat04-4
			FP_LED_close(FP_Serial);	//FP_GOsmat04-5
		}								//FP_GOsmat04-6
		return(0);						//FP_GOsmat04-7
	} 									//FP_GOsmat04-8
} 										//FP_GOsmat05

/*
int FPS_ID(FPS_GT511C3 &fps)
{					//FP_GOsmat
//unsigned char choose_function;   		//for menu handle
fps.SetLED(true);
if (fps.IsPressFinger())
	{
		fps.CaptureFinger(false);
		int id = fps.Identify1_N();
		
	     
		if (id <200) //<- change id value depending model you are using
		{//if the fingerprint matches, provide the matching template ID
			//Serial.print("Verified ID:");
			//Serial.println(id);
			return(1);
		}
		else
		{//if unable to recognize
			//Serial.println("Finger not found");
			return(0);
		}
	}
	//else
	//{
	//	Serial.println("Please press finger");
	//}
	return(0);
	//delay(100);
}
*/